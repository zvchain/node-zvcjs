See test.js for details.
